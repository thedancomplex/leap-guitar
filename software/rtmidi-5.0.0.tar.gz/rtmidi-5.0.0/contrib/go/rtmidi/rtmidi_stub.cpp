#include "../../../RtMidi.h"

#include "../../../RtMidi.cpp"
#include "../../../rtmidi_c.cpp"
